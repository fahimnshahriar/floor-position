# Dyeing Floor Tracker

Static web page (GitHub Pages) + Google Apps Script API + Google Sheet.

- **Operators** (Unit 1: 22, 1-21, 23 / Unit 2: 101-106) update Buyer, Color, Load time, Position - **only while the admin has started positioning**. When closed, the board is view-only.
- **Admin tab** (password): START / STOP positioning.
- **Image / Excel buttons** (top right, no login): export the Floor Position form any time.
- On STOP, the final board is copied to the **Archive** sheet. A printable **Floor Position** sheet is always auto-filled.

```
src/   Code.gs, appsscript.json   -> Google Apps Script (API)
docs/  index.html                 -> operator + admin page (GitHub Pages)
```

## Setup

1. New Google Sheet -> Extensions -> Apps Script. Paste `src/Code.gs`. Run `setup()` once (approve permissions).
2. Deploy -> New deployment -> Web app. Execute as **Me**, access **Anyone**. Copy the `/exec` URL.
3. Edit `docs/index.html`: set `API_URL` to that URL. Commit.
4. GitHub repo -> Settings -> Pages -> Deploy from branch `main`, folder `/docs`. Share the Pages URL with operators.
5. Open the page -> Admin tab -> login with `654321` (set by `ADMIN_PASSWORD` in `Code.gs`).

## Daily use

1. Admin opens Admin tab, presses START at the planned time (e.g. 11:45 PM).
2. Operators update their machines.
3. Admin presses STOP, then anyone taps Image / Excel (top right) to export.

## Updating code

Edit `Code.gs`, paste into Apps Script, then Deploy -> Manage deployments -> Edit -> New version.
Edit `docs/index.html` on GitHub; Pages updates in about a minute.
