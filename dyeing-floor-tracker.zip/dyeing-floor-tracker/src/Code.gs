/**
 * Dyeing Floor Tracker - Apps Script API (backend only)
 * The operator/admin page is a static HTML file (docs/index.html, e.g. GitHub Pages)
 * that calls this web app URL.
 *
 * Sheets: Live (current data) | Floor Position (printable form) | Archive (history at each STOP)
 * Run setup() once. Admin password is the ADMIN_PASSWORD constant above.
 */
const LIVE = 'Live', REP = 'Floor Position', ARC = 'Archive';
const SALT = 'dft-v1';
const ADMIN_PASSWORD = '654321'; // change here if ever needed, then redeploy

const MACHINES = [22].concat(Array.from({length: 21}, (_, i) => i + 1), [23], [101, 102, 103, 104, 105, 106]);
const CAP = {22:1500,1:1500,2:1500,3:1200,4:1200,5:1000,6:1000,7:1000,8:750,9:750,10:750,
  11:500,12:300,13:250,14:250,15:400,16:180,17:500,18:500,19:180,20:100,21:100,23:1000,
  101:1500,102:900,103:750,104:500,105:400,106:200};
const POS = ['MC wash','Scouring','Scouring steam up','Scouring cooling','Scouring addition',
  'Scouring N/hot','Scouring acid/RTU','Enzyme','Enzyme wash','Levelling','Color dosing',
  'Color run time','Salt dosing','Salt run time','Migration','Soda dosing','1st soda dosing',
  '2nd soda dosing','Color steam','Add color dosing','BD wash','Soaping hot ST up',
  'Soaping hot wash','Softener','Fixing'];
const BUYERS = ['AMERICAN Tall','ARDON','AEON','AS COLOR','CAPRICON','CISALFA','COTTON HERITAGE',
  'ICE BERG','B&C','MATALAN','NEW YORKER','LPP','FASHION UK','PROMOSET','DMR','MALFINI',
  'CENTENLINE','ALL GOODS','SALLING','MN DYEING','CAMEL','DUCATI','KAUFMANN','RECOVARY FAB',
  'EL CORTE','MODYF','KSL','HENRY','KARIBAN','NUTMEG','WELLENSTEYN','MAYORAL','P&C','LIMA',
  'ANTHEM','ZXY','COMODO','JEANS','BOSTON','TG','SUM OF IN HOUSE','ALIB','APEX','APS','MANAMI',
  'FORTIS','FOUR H','AKH','HABITUS','HAMS','JM','KA DESIGN','IRISH DESIGN','SUPREME','LIZ',
  'FASHION ASIA','MS FABRICS','PENTAGON','RADIANCE','RAGADI','RHINO','SILKEN','MARB TEX','SQ',
  'AC MILAN','QUATTRO FASHION','GILDEN','HK-DREAM'];

/* ---------- HTTP entry points ---------- */
function doGet() { return out_({ok: true, msg: 'Dyeing Floor Tracker API'}); }

function doPost(e) {
  let res;
  try { res = route_(JSON.parse(e.postData.contents)); }
  catch (err) { res = {ok: false, error: String(err && err.message || err)}; }
  return out_(res);
}
function out_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}

function route_(r) {
  switch (r.action) {
    case 'boot':
      return {ok: true, cfg: {cap: CAP, pos: POS, buyers: BUYERS,
        u1: MACHINES.filter(m => m < 100), u2: MACHINES.filter(m => m >= 100)},
        status: getState_(), data: readLive_()};
    case 'data':  return {ok: true, status: getState_(), data: readLive_()};
    case 'save':  return save_(r);
    case 'clear': return clear_(r);
    case 'login': return login_(r);
    case 'logout': CacheService.getScriptCache().remove('tok_' + r.token); return {ok: true};
    case 'start': needAdmin_(r); return start_(r);
    case 'stop':  needAdmin_(r); return stop_();
  }
  throw new Error('Unknown action');
}

/* ---------- Session state (open / closed) ---------- */
function getState_() {
  const s = PropertiesService.getScriptProperties().getProperty('STATE');
  return s ? JSON.parse(s) : {open: false, startedAt: 0, stoppedAt: 0};
}
function setState_(o) { PropertiesService.getScriptProperties().setProperty('STATE', JSON.stringify(o)); }

function start_(r) {
  const lock = LockService.getScriptLock(); lock.waitLock(10000);
  try {
    if (r.clearOld) clearAll_();
    setState_({open: true, startedAt: Date.now(), stoppedAt: 0});
  } finally { lock.releaseLock(); }
  return {ok: true, status: getState_(), data: readLive_()};
}

function stop_() {
  const lock = LockService.getScriptLock(); lock.waitLock(10000);
  try {
    const st = getState_();
    if (!st.open) throw new Error('Positioning is already stopped');
    const now = Date.now();
    archive_(st.startedAt, now);
    setState_({open: false, startedAt: st.startedAt, stoppedAt: now});
  } finally { lock.releaseLock(); }
  return {ok: true, status: getState_(), data: readLive_()};
}

function archive_(startMs, stopMs) {
  const ss = SpreadsheetApp.getActive();
  let a = ss.getSheetByName(ARC);
  if (!a) {
    a = ss.insertSheet(ARC);
    a.appendRow(['SESSION START','SESSION STOP','MC','CAPACITY','BUYER','COLOR','LOAD TIME','POSITION']);
    a.getRange(1, 1, 1, 8).setFontWeight('bold').setBackground('#d9e2f3');
    a.setFrozenRows(1);
  }
  const tz = Session.getScriptTimeZone();
  const f = t => Utilities.formatDate(new Date(t), tz, 'dd MMM yyyy HH:mm');
  const d = readLive_();
  const rows = MACHINES.filter(m => d[m]).map(m =>
    [f(startMs), f(stopMs), m, CAP[m], d[m].buyer, d[m].color, d[m].loadTxt, d[m].pos]);
  if (rows.length) a.getRange(a.getLastRow() + 1, 1, rows.length, 8).setValues(rows);
}

/* ---------- Admin login ---------- */
function hash_(p) {
  return Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, SALT + p));
}
function login_(r) {
  const cache = CacheService.getScriptCache();
  const fails = Number(cache.get('fails') || 0);
  if (fails >= 5) throw new Error('Too many attempts. Try again in 10 minutes.');
  if (hash_(String(r.password || '')) !== hash_(ADMIN_PASSWORD)) {
    cache.put('fails', String(fails + 1), 600);
    throw new Error('Wrong password');
  }
  cache.remove('fails');
  const t = Utilities.getUuid();
  cache.put('tok_' + t, '1', 21600); // 6 hours
  return {ok: true, token: t};
}
function needAdmin_(r) {
  if (!r.token || !CacheService.getScriptCache().get('tok_' + r.token)) throw new Error('Admin login required');
}

/* ---------- Operator actions (only while OPEN) ---------- */
function save_(r) {
  if (!getState_().open) throw new Error('Positioning is closed. Wait for admin to start.');
  const mc = Number(r.mc), idx = MACHINES.indexOf(mc);
  const buyer = String(r.buyer || '').trim(), color = String(r.color || '').trim();
  const p = POS.filter(x => x.toLowerCase() === String(r.pos || '').trim().toLowerCase())[0];
  if (idx < 0) throw new Error('Unknown machine');
  if (!buyer) throw new Error('Buyer is required');
  if (!p) throw new Error('Pick a position from the list');
  const mon = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const m = /^(\d{4})-(\d\d)-(\d\d)T(\d\d:\d\d)/.exec(r.load || '');
  const loadTxt = m ? (m[3] + ' ' + mon[Number(m[2]) - 1] + ' ' + m[4]) : '';
  const now = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'dd MMM HH:mm');
  const lock = LockService.getScriptLock(); lock.waitLock(10000);
  try {
    SpreadsheetApp.getActive().getSheetByName(LIVE)
      .getRange(idx + 2, 3, 1, 6).setValues([[buyer, color, loadTxt, p, now, r.load || '']]);
  } finally { lock.releaseLock(); }
  return {ok: true, status: getState_(), data: readLive_()};
}

function clear_(r) {
  if (!getState_().open) throw new Error('Positioning is closed.');
  const idx = MACHINES.indexOf(Number(r.mc));
  if (idx < 0) throw new Error('Unknown machine');
  const lock = LockService.getScriptLock(); lock.waitLock(10000);
  try { SpreadsheetApp.getActive().getSheetByName(LIVE).getRange(idx + 2, 3, 1, 6).clearContent(); }
  finally { lock.releaseLock(); }
  return {ok: true, status: getState_(), data: readLive_()};
}

function clearAll_() {
  SpreadsheetApp.getActive().getSheetByName(LIVE).getRange(2, 3, MACHINES.length, 6).clearContent();
}

function readLive_() {
  const ss = SpreadsheetApp.getActive();
  if (!ss) throw new Error('Script is not attached to a Google Sheet. Create it from the Sheet: Extensions > Apps Script.');
  let s = ss.getSheetByName(LIVE);
  if (!s) { setup(); s = ss.getSheetByName(LIVE); } // auto-create sheets on first use
  const v = s.getRange(2, 1, MACHINES.length, 8).getValues();
  const o = {};
  v.forEach(r => { if (r[2] || r[5]) o[r[0]] = {buyer: r[2], color: r[3], loadTxt: r[4], pos: r[5], at: r[6], load: r[7]}; });
  return o;
}

/* ---------- One-time setup (run manually) ---------- */
function setup() {
  const ss = SpreadsheetApp.getActive(), n = MACHINES.length;
  const live = ss.getSheetByName(LIVE) || ss.insertSheet(LIVE);
  live.clear();
  live.getRange(1, 1, 1, 8).setValues([['MC','CAPACITY','BUYER','COLOR','LOAD TIME','POSITION','UPDATED AT','LOAD ISO']])
    .setFontWeight('bold').setBackground('#d9e2f3');
  live.getRange(2, 3, n, 6).setNumberFormat('@');
  live.getRange(2, 1, n, 2).setValues(MACHINES.map(m => [m, CAP[m]]));
  live.setFrozenRows(1); live.hideColumns(8);

  const r = ss.getSheetByName(REP) || ss.insertSheet(REP);
  r.getRange(1, 1, r.getMaxRows(), r.getMaxColumns()).breakApart(); r.clear();
  r.getRange('A1:F1').merge().setValue('FLOOR POSITION');
  r.getRange('A2:B2').merge().setValue('DATE');
  r.getRange('C2').setFormula('=TODAY()').setNumberFormat('dd/mm/yyyy');
  r.getRange('E2').setValue('TIME');
  r.getRange('F2').setFormula('=NOW()').setNumberFormat('hh:mm');
  r.getRange('A3:F3').setValues([['MC','CAPACITY','BUYER','COLOR','LOAD TIME','POSITION']]);
  r.getRange(4, 1, n, 6).setFormulas(MACHINES.map((m, i) => [m, CAP[m]].concat(
    ['C','D','E','F'].map(c => '=IF(Live!' + c + (i + 2) + '="","",Live!' + c + (i + 2) + ')'))));
  r.getRange(1, 1, 3 + n, 6).setBorder(true, true, true, true, true, true)
    .setHorizontalAlignment('center').setVerticalAlignment('middle');
  r.getRange('A1:F3').setFontWeight('bold');
  r.getRange('A1:F1').setBackground('#d9e2f3').setFontSize(12);
  [60, 80, 180, 140, 120, 190].forEach((w, i) => r.setColumnWidth(i + 1, w));
  r.setFrozenRows(3);

  setState_({open: false, startedAt: 0, stoppedAt: 0});
}


/* ---------- Run from the Apps Script editor (for testing / emergency) ---------- */
function checkStatus() { Logger.log(JSON.stringify(getState_())); }
function manualStart() { Logger.log(JSON.stringify(start_({clearOld: true}).status)); }
function manualStop()  { Logger.log(JSON.stringify(stop_().status)); }
